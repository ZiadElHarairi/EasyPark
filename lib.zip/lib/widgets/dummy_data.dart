// import 'package:flutter/material.dart';
// import '../models/Users.dart';
// import '../models/userTransactions.dart';

// // import './models/meal.dart';
// const DUMMY_ACCOUNTS = const [
//   Account(
//     name: 'Ziad',
//     email: 'zelharairi@gmail.com',
//     pw: '12345',
//     pNum: 01229966996,
//     visits: [
//       Visit(
//         startTime: '08:45 AM',
//         endTime: '12:45 PM',
//         date: '5/7/2021',
//         amount: 40.00,
//       ),
//       Visit(
//         startTime: '11:05 AM',
//         endTime: '01:04 PM',
//         date: '17/5/2021',
//         amount: 20.00,
//       ),
//     ],
//   ),
// ];
// const DUMMY_VISITS = const [
//   Visit(
//     startTime: '08:45 AM',
//     endTime: '12:45 PM',
//     date: '5/7/2021',
//     amount: 40.00,
//   ),
//   Visit(
//     startTime: '11:05 AM',
//     endTime: '01:04 PM',
//     date: '17/5/2021',
//     amount: 20.00,
//   ),
//   Visit(
//     startTime: '12:19 PM',
//     endTime: '03:51 PM',
//     date: '9/5/2021',
//     amount: 40.00,
//   ),
//   Visit(
//     startTime: '09:00 PM',
//     endTime: '10:27 PM',
//     date: '3/5/2021',
//     amount: 20.00,
//   ),
//   Visit(
//     startTime: '09:41 AM',
//     endTime: '11:03 AM',
//     date: '8/4/2021',
//     amount: 20.00,
//   ),
//   Visit(
//     startTime: '06:05 PM',
//     endTime: '08:35 PM',
//     date: '7/4/2021',
//     amount: 30.00,
//   ),
//   Visit(
//     startTime: '01:45 PM',
//     endTime: '02:35 PM',
//     date: '23/3/2021',
//     amount: 10.00,
//   ),
//   Visit(
//     startTime: '10:15 AM',
//     endTime: '11:05 AM',
//     date: '10/2/2021',
//     amount: 10.00,
//   ),
//   Visit(
//     startTime: '01:45 PM',
//     endTime: '02:44 PM',
//     date: '7/2/2021',
//     amount: 10.00,
//   ),
//   Visit(
//     startTime: '01:45 PM',
//     endTime: '2:45 PM',
//     date: '7/1/2021',
//     amount: 20.00,
//   ),
//   Visit(
//     startTime: '12:45 PM',
//     endTime: '06:43 PM',
//     date: '7/12/2020',
//     amount: 60.00,
//   ),
//   Visit(
//     startTime: '08:37 AM',
//     endTime: '01:05 PM',
//     date: '7/11/2020',
//     amount: 50.00,
//   ),
//   Visit(
//     startTime: '04:23 PM',
//     endTime: '08:45 PM',
//     date: '7/10/2020',
//     amount: 50.00,
//   ),
//   Visit(
//     startTime: '01:45 PM',
//     endTime: '02:45 PM',
//     date: '7/9/2020',
//     amount: 20.00,
//   ),
// ];
